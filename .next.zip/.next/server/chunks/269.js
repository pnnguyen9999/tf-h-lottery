"use strict";
exports.id = 269;
exports.ids = [269];
exports.modules = {

/***/ 6058:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$9": () => (/* binding */ setHistoryPersonalData),
/* harmony export */   "Dz": () => (/* binding */ setlatestLotteryData),
/* harmony export */   "Hn": () => (/* binding */ setOnCalculatingTime),
/* harmony export */   "J9": () => (/* binding */ setOpenPopupBuyTicket),
/* harmony export */   "Jx": () => (/* binding */ setCurrentLotteryId),
/* harmony export */   "LG": () => (/* binding */ setlatestLotteryId),
/* harmony export */   "Mg": () => (/* binding */ setOpenPopupStatus),
/* harmony export */   "QV": () => (/* binding */ setlatestPersonalData),
/* harmony export */   "RZ": () => (/* binding */ setlatestHegemLotteryData),
/* harmony export */   "V": () => (/* binding */ setHistoryLotteryData),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "fI": () => (/* binding */ setOpenPersonalTicketInfo),
/* harmony export */   "gC": () => (/* binding */ setLoadingHistoryLotteryData),
/* harmony export */   "hi": () => (/* binding */ setOpenHistoryPersonalTicketInfo),
/* harmony export */   "jP": () => (/* binding */ setOpenLoadingPopup),
/* harmony export */   "rK": () => (/* binding */ setCurrentHistoryLottery),
/* harmony export */   "rQ": () => (/* binding */ setNumberOfWinningTicket),
/* harmony export */   "s8": () => (/* binding */ setMaxAmountCanBuy),
/* harmony export */   "ts": () => (/* binding */ setlatestHegemLotteryId),
/* harmony export */   "vo": () => (/* binding */ setLoadinglatestLotteryData)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
  currentHistoryLottery: 'hera',
  // lotteryOrder: ["hegem", "hera"],
  isOpenPersonalTicketInfo: false,
  isOpenPersonalHistoryTicketInfo: false,
  isOpenLoadingPopup: false,
  currentLotteryId: null,
  historyLotteryData: null,
  loadinghistoryLotteryData: false,
  latestLotteryId: null,
  latestHegemLotteryId: null,
  latestLotteryData: null,
  latestHegemLotteryData: null,
  loadinglatestLotteryData: false,
  latestPersonalData: null,
  historyPersonalData: null,
  loadinghistoryPersonalData: false,
  numberOfWinningTickets: [],
  isOpenPopupStatus: {
    isOpen: false,
    type: 'fail',
    message: ''
  },
  maxAmountCanBuy: 0,
  isOpenPopupBuyTicket: false,
  isOnCalculatingTime: false
};
const globalState = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'globalState',
  initialState,
  reducers: {
    setlatestLotteryId: (state, {
      payload
    }) => {
      state.latestLotteryId = payload;
    },
    setlatestHegemLotteryId: (state, {
      payload
    }) => {
      state.latestHegemLotteryId = payload;
    },
    setCurrentLotteryId: (state, {
      payload
    }) => {
      state.currentLotteryId = payload;
    },
    setCurrentHistoryLottery: (state, {
      payload
    }) => {
      state.currentHistoryLottery = payload;
    },
    setHistoryLotteryData: (state, {
      payload
    }) => {
      state.historyLotteryData = payload;
    },
    setlatestLotteryData: (state, {
      payload
    }) => {
      state.latestLotteryData = payload;
    },

    setlatestHegemLotteryData(state, {
      payload
    }) {
      state.latestHegemLotteryData = payload;
    },

    setlatestPersonalData: (state, {
      payload
    }) => {
      state.latestPersonalData = payload;
    },
    setHistoryPersonalData: (state, {
      payload
    }) => {
      state.historyPersonalData = payload;
    },
    setLoadingPersonalLotteryData: (state, {
      payload
    }) => {
      state.loadinghistoryPersonalData = payload;
    },
    setLoadingHistoryLotteryData: (state, {
      payload
    }) => {
      state.loadinghistoryLotteryData = payload;
    },
    setLoadinglatestLotteryData: (state, {
      payload
    }) => {
      state.loadinghistoryLotteryData = payload;
    },
    setOpenPersonalTicketInfo: (state, {
      payload
    }) => {
      state.isOpenPersonalTicketInfo = payload;
    },
    setOpenHistoryPersonalTicketInfo: (state, {
      payload
    }) => {
      state.isOpenPersonalHistoryTicketInfo = payload;
    },
    setNumberOfWinningTicket: (state, {
      payload
    }) => {
      state.numberOfWinningTickets = payload;
    },
    setOpenPopupStatus: (state, {
      payload
    }) => {
      state.isOpenPopupStatus = {
        isOpen: payload.isOpen,
        type: payload.type,
        message: payload.message
      };
    },
    setMaxAmountCanBuy: (state, {
      payload
    }) => {
      state.maxAmountCanBuy = payload;
    },
    setOpenPopupBuyTicket: (state, {
      payload
    }) => {
      state.isOpenPopupBuyTicket = payload;
    },
    setOnCalculatingTime: (state, {
      payload
    }) => {
      state.isOnCalculatingTime = payload;
    },
    setOpenLoadingPopup: (state, {
      payload
    }) => {
      state.isOpenLoadingPopup = payload;
    }
  }
});
const {
  setCurrentLotteryId,
  setHistoryLotteryData,
  setLoadingHistoryLotteryData,
  setlatestLotteryData,
  setlatestHegemLotteryData,
  setCurrentHistoryLottery,
  setLoadinglatestLotteryData,
  setlatestLotteryId,
  setlatestHegemLotteryId,
  setlatestPersonalData,
  setOpenPersonalTicketInfo,
  setHistoryPersonalData,
  setOpenHistoryPersonalTicketInfo,
  setNumberOfWinningTicket,
  setOpenPopupStatus,
  setMaxAmountCanBuy,
  setOpenPopupBuyTicket,
  setOnCalculatingTime,
  setOpenLoadingPopup
} = globalState.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (globalState.reducer);

/***/ }),

/***/ 5018:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z4": () => (/* binding */ setTotalRewardRx),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zi": () => (/* binding */ setAllTicketsRewardRx),
/* harmony export */   "w4": () => (/* binding */ setOpenPopupReward)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
  isOpenPopupReward: false,
  totalRewardRx: {
    hegemReward: 0,
    heraReward: 0
  },
  allTicketsRewardRx: []
};
const rewardState = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "rewardState",
  initialState,
  reducers: {
    setOpenPopupReward: (state, {
      payload
    }) => {
      state.isOpenPopupReward = payload;
    },
    setTotalRewardRx: (state, {
      payload
    }) => {
      state.totalRewardRx = payload;
    },
    setAllTicketsRewardRx: (state, {
      payload
    }) => {
      state.allTicketsRewardRx = payload;
    }
  }
});
const {
  setOpenPopupReward,
  setTotalRewardRx,
  setAllTicketsRewardRx
} = rewardState.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rewardState.reducer);

/***/ }),

/***/ 6680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q4": () => (/* binding */ setTriggerConnectWalletUseEff),
/* harmony export */   "Rk": () => (/* binding */ setTriggerCurrentPersonalDataUseEff),
/* harmony export */   "VN": () => (/* binding */ setTriggerLatestDataUseEff),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
  triggerLatestDataUseEff: false,
  triggerCurrentPersonalDataUseEff: false,
  triggerConnectWalletUseEff: false
};
const triggerState = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "triggerState",
  initialState,
  reducers: {
    setTriggerLatestDataUseEff: state => {
      state.triggerLatestDataUseEff = !state.triggerLatestDataUseEff;
    },
    setTriggerConnectWalletUseEff: state => {
      state.triggerConnectWalletUseEff = !state.triggerConnectWalletUseEff;
    },
    setTriggerCurrentPersonalDataUseEff: state => {
      state.triggerCurrentPersonalDataUseEff = !state.triggerCurrentPersonalDataUseEff;
    }
  }
});
const {
  setTriggerLatestDataUseEff,
  setTriggerConnectWalletUseEff,
  setTriggerCurrentPersonalDataUseEff
} = triggerState.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (triggerState.reducer);

/***/ }),

/***/ 2321:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lu": () => (/* binding */ setBalance),
/* harmony export */   "Pk": () => (/* binding */ setUtilsWallet),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zb": () => (/* binding */ setAllowance),
/* harmony export */   "qj": () => (/* binding */ setAddress)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
  utilsWallet: null,
  address: null,
  balance: null,
  allowance: null
};
const web3 = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "web3",
  initialState,
  reducers: {
    setUtilsWallet: (state, {
      payload
    }) => {
      state.utilsWallet = payload;
    },
    setAddress: (state, action) => {
      state.address = action.payload;
    },
    setBalance: (state, action) => {
      state.balance = action.payload;
    },
    setAllowance: (state, {
      payload
    }) => {
      state.allowance = payload;
    }
  }
});
const {
  setUtilsWallet,
  setAddress,
  setBalance,
  setAllowance
} = web3.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (web3.reducer);

/***/ })

};
;